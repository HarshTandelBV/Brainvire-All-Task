import base64
from odoo import fields, models, api
from odoo.exceptions import ValidationError
import io
import xlsxwriter
from odoo.tools.misc import xlsxwriter as odoo_xlsxwriter
from odoo import models


class EventExcelReport(models.TransientModel):
    _name = "event.excel.report"
    _description = "This is a wizard which will generate the Event Excel report"

    file = fields.Binary('Prepared file', readonly=True, attachment=True)
    file_name = fields.Char('File Name', readonly=True)

    def print_xlsx_report(self):

        output = io.BytesIO()
        workbook = xlsxwriter.Workbook(output, {'in_memory': True})
        worksheet = workbook.add_worksheet('Excel Report')
        # invoice_worksheet = workbook.add_worksheet('Customer Details')

        # Formatting the data
        header_format = workbook.add_format({'bold': True, 'align': 'center', 'font_size': 10, 'valign': 'vcenter',
                                             'fg_color': '#D3C5E5', 'font_color': '#735DA5', 'border': 1})

        title_format = workbook.add_format({'bold': True, 'align': 'center', 'font_size': 16, 'valign': 'vcenter',
                                            'fg_color': '#735DA5', 'font_color': 'white'})

        cell_format = workbook.add_format({'fg_color': '#E6E3EA', 'border': 1})
        cell_date_format = workbook.add_format(
            {'num_format': 'dd-mm-yyyy', 'align': 'right', 'fg_color': '#E6E3EA', 'border': 1})
        cell_numeric_format = workbook.add_format(
            {'align': 'right', 'fg_color': '#E6E3EA', 'border': 1})
        cell_amount_format = workbook.add_format(
            {'num_format': '#,##0.00', 'align': 'right', 'fg_color': '#E6E3EA', 'border': 1})

        # Fetching the data
        events = self.env['event.event.report'].search([])

        worksheet.merge_range('A1:J1', f'Event Report', title_format)
        worksheet.set_row(0, 40)
        worksheet.set_row(1, 30)
        worksheet.set_column('A:A', 20)  # Name
        worksheet.set_column('B:B', 30)  # Description
        worksheet.set_column('C:C', 40)  # Start Date
        worksheet.set_column('D:D', 20)  # End Data
        worksheet.set_column('E:E', 20)  # Location
        worksheet.set_column('F:F', 30)  # Reg Start Date
        worksheet.set_column('G:G', 15)  # Reg End Date
        worksheet.set_column('H:H', 15)  # Total Sessions
        worksheet.set_column('I:I', 15)  # Reg End Date
        worksheet.set_column('J:J', 15)  # Reg End Date

        worksheet.write('A2', 'Name', header_format)
        worksheet.write('B2', 'Description', header_format)
        worksheet.write('C2', 'Start Date', header_format)
        worksheet.write('D2', 'End Data', header_format)
        worksheet.write('E2', 'Location', header_format)
        worksheet.write('F2', 'Reg Start Date', header_format)
        worksheet.write('G2', 'Reg End Date', header_format)
        worksheet.write('H2', 'Total Sessions', header_format)
        worksheet.write('I2', 'Total Tickets', header_format)
        worksheet.write('J2', 'Total Attendee', header_format)


        row = 2

        for event in events:
            col = 0
            worksheet.write(row, col, event.name or '', cell_format)
            col += 1
            worksheet.write(row, col, event.description or '', cell_format)
            col += 1
            worksheet.write(row, col, event.start_date or '', cell_format)
            col += 1
            worksheet.write(row, col, event.end_date or '', cell_date_format)
            col += 1
            worksheet.write(row, col, event.location or '', cell_format)
            col += 1
            worksheet.write(row, col, event.registration_open_date or '', cell_format)
            col += 1
            worksheet.write(row, col, event.registration_close_date or '', cell_format)
            col += 1
            worksheet.write(row, col, event.session_count or '', cell_format)
            col += 1
            worksheet.write(row, col, event.ticket_count or '', cell_format)
            col += 1
            worksheet.write(row, col, event.attendee_count or '', cell_format)
            row += 1


        workbook.close()
        output.seek(0)
        file_data = output.read()
        output.close()

        self.write({
            'file': base64.b64encode(file_data),
            'file_name': 'event_report.xlsx'
        })

        return {
            'type': 'ir.actions.act_url',
            'url': '/web/content/?model=%s&id=%s&field=file&download=true&filename=%s' % (
                self._name, self.id, self.file_name),
            'target': 'New',
        }
